// return les <td> (html elements) d'un element <table>
// parametre : id du <table>
function getAllCellsOfRowTable(elemID){
    var t = document.getElementById(elemID);
    return t.getElementsByTagName("TD");
}

// 
function transpose4x4data(dataArray){
    return [
        dataArray[0],dataArray[4],dataArray[ 8],dataArray[12],
        dataArray[1],dataArray[5],dataArray[ 9],dataArray[13],
        dataArray[2],dataArray[6],dataArray[10],dataArray[14],
        dataArray[3],dataArray[7],dataArray[11],dataArray[15]
    ];
}


function set4x4table(cells, floatArray){
    var f;
    var p;
    for (var iCell = 0; iCell < 16; iCell++) {
        
        p = (floatArray[iCell] > 0) ? true : false;

        f = floatArray[iCell];
        if((""+f).search("e") != -1) f = f.toFixed(1);

        f = ""+f;
        if(p){
            f = "+"+f[0]+f[1]+f[2];
            f = ""+parseFloat(f);
        }else{ 
            f = f[0]+f[1]+f[2]+f[3];
            f = ""+parseFloat(f);
        }
        cells[iCell].textContent = f;
    }
}