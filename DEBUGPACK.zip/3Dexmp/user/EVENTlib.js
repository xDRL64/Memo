function makeMouseDeltaSystem(htmlElem){

	var mymouse = {};

	mymouse.movex = false;
	mymouse.movey = false;

	Object.defineProperty(mymouse, "dx",{
		get: function(){
			var tmp = this.deltax;
			if(!this.movex){
				this.deltax = 0;
				tmp = 0;
			}
			else
				this.movex = false;
			return tmp;
		}
	});

	Object.defineProperty(mymouse, "dy",{
		get: function(){
			var tmp = this.deltay;
			if(!this.movey){
				this.deltay = 0;
				tmp = 0;
			}
			else
				this.movey = false;
			return tmp;
		}
	});


	htmlElem.addEventListener("mousedown", function(e){

		mymouse.lastx = e.screenX;
		mymouse.lasty = e.screenY;

		mymouse.deltax = 0;
		mymouse.deltay = 0;

		document.addEventListener("mousemove", mymouse.eClick = function(e){

			mymouse.movex = true;
			mymouse.movey = true;

			mymouse.deltax = mymouse.lastx == e.screenX ? 0 : e.screenX - mymouse.lastx;
			mymouse.deltay = mymouse.lasty == e.screenY ? 0 : e.screenY - mymouse.lasty;

			mymouse.lastx = e.screenX;
			mymouse.lasty = e.screenY;
			//debug.textContent = "dx: "+mymouse.deltax+"\ndy: "+mymouse.deltay;
		});

	});

	document.addEventListener("mouseup", function(e){
		document.removeEventListener("mousemove", mymouse.eClick);
	});

	mymouse.refresh = function(){
		mymouse.deltax = 0;
		mymouse.deltay = 0;
	};

	return mymouse;
}
