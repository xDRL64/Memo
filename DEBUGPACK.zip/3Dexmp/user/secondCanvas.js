	

secondRenderer = (function(canvasID){

    var scene, camera, renderer;
	var width, height;
	var canvas;
	var objParent;
	var mymouse;

    var axisLen = 1;


	//var debug = document.getElementById("debug");
	canvas = document.getElementById(canvasID);
	width = canvas.clientWidth;
	height = canvas.clientHeight;

	scene = new THREE.Scene();
	camera = new THREE.PerspectiveCamera(90, width/height, .1, 500);
	renderer = new THREE.WebGLRenderer();
	renderer.setSize(width, height);
	objParent = canvas.parentNode;
	objParent.replaceChild(renderer.domElement, canvas);
	canvas = renderer.domElement;


	var camDist = 3;
	camera.position.set(camDist,camDist,camDist);
	camera.lookAt(scene.position);
	renderer.render(scene, camera);

	var camRight = new THREE.Vector3(0,1,0);
	camRight.crossVectors(camRight,camera.getWorldDirection());
	camRight = [camRight.x, camRight.y, camRight.z];

	var rightcamLine = makeLine([0,0,0], [-camRight[0]*10,camRight[1]*10,-camRight[2]*10], 0xFF00FF);
    scene.add(rightcamLine);

    var grid = new THREE.GridHelper( 2.5, 1 );
    scene.add( grid );

    var wAxis = makeWorldAxis(4,0xFF0000,0x00FF00,0x0000FF);
    scene.add( wAxis );
    
	var axis = makeWorldAxis(axisLen,0xFFBBBB,0xBBFFBB,0xBBBBFF);
    axis.userData.len = axisLen;
    scene.add( axis );

    var zeroFGaxis = makeWorldAxis(axisLen,0xFFBBBB,0xBBFFBB,0xBBBBFF);
    zeroFGaxis.children.forEach(function(elem) {
        elem.material.depthTest = false;
        elem.renderOrder = 1;
    });
    zeroFGaxis.userData.obj = zeroFGaxis;
    zeroFGaxis.userData.main = function (){
        var r = mainRenderer.o.rotation;
        if((r.x+r.y+r.z)==0) this.obj.visible = true;
        else this.obj.visible = false;
    };
    scene.add( zeroFGaxis );



    main = function(){
        //doRotationFromWorldSpaceAxis([0,1,0], this.m.dx, this.o);
		//doRotationFromWorldSpaceAxis(this.cright, -this.m.dy, this.o);

        m = BUFFER_MATRIX;

        this.o.children[0].geometry.vertices[1].x = m[0] * this.o.userData.len;
        this.o.children[0].geometry.vertices[1].y = m[1] * this.o.userData.len;
        this.o.children[0].geometry.vertices[1].z = m[2] * this.o.userData.len;
        this.o.children[0].geometry.verticesNeedUpdate = true;

        this.o.children[1].geometry.vertices[1].x = m[4] * this.o.userData.len;
        this.o.children[1].geometry.vertices[1].y = m[5] * this.o.userData.len;
        this.o.children[1].geometry.vertices[1].z = m[6] * this.o.userData.len;
        this.o.children[1].geometry.verticesNeedUpdate = true;

        this.o.children[2].geometry.vertices[1].x = m[ 8] * this.o.userData.len;
        this.o.children[2].geometry.vertices[1].y = m[ 9] * this.o.userData.len;
        this.o.children[2].geometry.vertices[1].z = m[10] * this.o.userData.len;
        this.o.children[2].geometry.verticesNeedUpdate = true;

        this.fixer.forEach(function(elem){elem.userData.main();});

        /*
        tmpMat4 = new THREE.Matrix4();
        tmpMat4.set(
            m[0],m[4],m[8],m[12], m[1],m[5],m[9],m[13],
            m[2],m[6],m[10],m[14], m[3],m[7],m[11],m[15]);
        // way 1 to apply matrix
        this.o.matrix = new THREE.Matrix4();
        this.o.applyMatrix(tmpMat4);
        // way 2 to apply matrix
        this.o.matrix.copy(tmpMat4);
        this.o.matrix.decompose(this.o.position,this.o.quaternion,this.o.scale);
        */

		this.r.render(this.s, this.c);
    }
    return {s:scene, c:camera, r:renderer, o:axis, cright:camRight, main:main, fixer:[zeroFGaxis]};



})("SecondCanvas");
    







