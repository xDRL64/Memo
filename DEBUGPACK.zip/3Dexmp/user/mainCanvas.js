	

mainRenderer = (function(canvasID){

    var scene, camera, renderer;
	var width, height;
	var canvas;
	var objParent;
	var mymouse;

	scene = new THREE.Scene();

	canvas = document.getElementById(canvasID);
	var debug = document.getElementById("debug");

	width = canvas.clientWidth;
	height = canvas.clientHeight;

	camera = new THREE.PerspectiveCamera(90, width/height, .1, 500);


	renderer = new THREE.WebGLRenderer({alpha: true});
    //renderer.domElement.style.backgroundColor = "rgba(0, 0, 0, 0)";

	renderer.setSize(width, height);
	objParent = canvas.parentNode;
	objParent.replaceChild(renderer.domElement, canvas);
	canvas = renderer.domElement;

	var cube = makePhongCube(1,1,1, 0xffffff);
    scene.add( cube );

	var axis = new THREE.AxisHelper( 3 );
	scene.add( axis );
	axis.parent = cube;

	var wAxis = makeWorldAxis(4,0xFF0000,0x00FF00,0x0000FF)
    scene.add( wAxis );

	var plane = makeUnlitYplane(5, 5, 0xffff00);
	plane.position.y = -0.5;
    scene.add( plane );

	var light = makePointLight(0xffffff, 1, 100);
	light.position.set( 2, 3, 4 );
    scene.add( light );

	mymouse = makeMouseDeltaSystem(canvas, mymouse);

	var camDist = 3;
	camera.position.set(camDist,camDist,camDist);
	camera.lookAt(scene.position);
	renderer.render(scene, camera);

	var camRight = new THREE.Vector3(0,1,0);
	camRight.crossVectors(camRight,camera.getWorldDirection());
	camRight = [camRight.x, camRight.y, camRight.z];

	rightcamLine = makeLine([0,0,0], [-camRight[0]*10,camRight[1]*10,-camRight[2]*10], 0xFF00FF);
    scene.add(rightcamLine);



    main = function(){
        doRotationFromWorldSpaceAxis([0,1,0], this.m.dx, this.o);
        if(!LOCK_Y)
		    doRotationFromWorldSpaceAxis(this.cright, -this.m.dy, this.o);
		
        BUFFER_MATRIX = this.o.matrix.elements;
        set4x4table(CELLS_ROWMATRIX, BUFFER_MATRIX);
        set4x4table(CELLS_COLMATRIX, BUFFER_MATRIX);

		this.r.render(this.s, this.c);
    }
    return {m:mymouse, s:scene, c:camera, r:renderer, o:cube, cright:camRight, main:main};



})("MainCanvas");
    
