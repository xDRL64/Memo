
function makeLine(start, end, color){
	var material = new THREE.LineBasicMaterial({ color: color });

	var geometry = new THREE.Geometry();
	geometry.vertices.push(
		new THREE.Vector3( start[0], start[1], start[2] ),
		new THREE.Vector3(   end[0],   end[1],   end[2] ),
	);

	var line = new THREE.Line( geometry, material );
	
	return line
}

function makeWorldAxis(length, rCol, uCol, fCol){
	var wAxis = new THREE.Object3D();
	wAxis.add( makeLine([0,0,0], [length,0,0], rCol) );
	wAxis.add( makeLine([0,0,0], [0,length,0], uCol) );
	wAxis.add( makeLine([0,0,0], [0,0,length], fCol) );
	return wAxis;
}

function makeUnlitYplane(width, height, color){
	var geometry = new THREE.PlaneGeometry( width, height);
	var material = new THREE.MeshBasicMaterial(
		{color: color, side: THREE.DoubleSide}
	);
	var plane = new THREE.Mesh( geometry, material );
	plane.rotation.x = Math.PI/2;
	
	return plane;
}

function makePhongCube(x,y,z, col){
    var geometry = new THREE.BoxGeometry( 1, 1, 1 );
	var material = new THREE.MeshPhongMaterial( { color: col, emissive: 0x222222 } );
	var cube = new THREE.Mesh( geometry, material );
	
	return cube;
}

function makePointLight(col, intensity, distance){
	var light = new THREE.PointLight( col, intensity, distance );
	
	return light;
}

function doRotationFromWorldSpaceAxis(axis, angle, object){
	var PI180 = (Math.PI/180);
	var v = new THREE.Vector3(axis[0], axis[1], axis[2]);
	v.normalize();

	var q = new THREE.Quaternion();
	q.setFromAxisAngle( v, angle * PI180 );;
	object.quaternion.multiplyQuaternions( q, object.quaternion );
}