
function doesItHaveASCIIafter(str, after=32){
	for(var iChar = 0; iChar < str.length; iChar++)
		if(str[iChar].charCodeAt() > after)
			return true;
	return false;
}

function cleanCode(startNode){
	var parent;
	var nextNode;
    if(startNode){
        var node = startNode.firstChild;
        while(node != null){
            if(node.nodeType == 3){
            	//if(!/([a-zA-Z0-9]{1})/i.test(node.textContent)){
            	if( !doesItHaveASCIIafter(node.textContent, " ".charCodeAt()) ){
            		nextNode = node.nextSibling;
            		node.parentNode.removeChild(node);
            		node = nextNode;
            	}else
            		node = node.nextSibling;
            }else{
            	cleanCode(node);
            	node = node.nextSibling;
            } 
        }
    }
}





	

function getAllTextNodeOf(node){
    var result = [];
    if(node){
        node= node.firstChild;
        while(node != null){
            if(node.nodeType == 3)
            	result[result.length]=node;
            else
            	result = result.concat(getAllTextNodeOf(node));
            node= node.nextSibling;
        }
    }
    return result;
}







// Attention pourait poser des probleme si,
// un des enfant de l'elements utilisent le style 'box-sizing: border-box';
function getRealWidth(elem){
	var realWidth = 0;
	var p = window.getComputedStyle(elem, null);
	realWidth += parseInt(p.marginLeft);
	realWidth += parseInt(p.marginRight);
	realWidth += parseInt(p.borderLeftWidth);
	realWidth += parseInt(p.borderRightWidth);
	realWidth += parseInt(p.paddingLeft);
	realWidth += parseInt(p.paddingRight);
	realWidth += parseInt(p.width);
	return realWidth;
}

// Attention pourait poser des probleme si,
// un des enfant de l'elements utilisent le style 'box-sizing: border-box';
function getRealHeight(elem){
	var realHeight = 0;
	var p = window.getComputedStyle(elem, null);
	realHeight += parseInt(p.marginTop);
	realHeight += parseInt(p.marginBottom);
	realHeight += parseInt(p.borderTopWidth);
	realHeight += parseInt(p.borderBottomWidth);
	realHeight += parseInt(p.paddingTop);
	realHeight += parseInt(p.paddingBottom);
	realHeight += parseInt(p.height);
	return realHeight;
}

function getRowContentSize(node){

	var widthTotal = 0;
	var heightMax  = 0;

	var childHeight;

	var htmlElems = node.children;

	var p;

	for(var iChild = 0; iChild < htmlElems.length; iChild++){

		widthTotal += getRealWidth(htmlElems[iChild]);
		
		childHeight = getRealHeight(htmlElems[iChild]);
		heightMax = childHeight > heightMax ? childHeight : heightMax;

		//widthTotal += htmlElems[iChild].scrollWidth; // border + width (+padding?) mais pas margin
		//heightMax = htmlElems[iChild].scrollHeight > heightMax ?
		//	htmlElems[iChild].scrollHeight : heightMax;

	}

	return {w:widthTotal, h:heightMax};
}

function resizeByRowContent(rowNode){
	realsize = getRowContentSize(rowNode);
	rowNode.style.width = ""+realsize.w+"px";
	rowNode.style.height = ""+realsize.h+"px";
}

// Attention peut poser des probleme si,
// un des elements enfant du premier enfant de 'body' (normalement a la class 'VISIBLEBODY'),
// contient des elements qui utilisent le style 'box-sizing: border-box';
function resizeBody(){

    if(document.body.children[0].className != "VISIBLEBODY")
	    console.log("attention le premier element n'est pas div");

	var blocks = document.body.children[0].children;

	var widthMax    = 0;
	var heightTotal = 0;

	for(var iBlock = 0; iBlock < blocks.length; iBlock++){
		resizeByRowContent(blocks[iBlock]);

		var blockWidth = getRealWidth(blocks[iBlock]);
		widthMax = blockWidth > widthMax ? blockWidth : widthMax;

        var blockHeight = getRealHeight(blocks[iBlock]);
        heightTotal += blockHeight;
	}
	document.body.style.width = ""+widthMax+"px";
	document.body.style.height = ""+heightTotal+"px";
}