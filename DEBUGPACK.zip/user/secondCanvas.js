	

secondRenderer = (function(canvasID){

	//var debug = document.getElementById("debug");
	var canvas = document.getElementById(canvasID);
	var width = canvas.clientWidth;
	var height = canvas.clientHeight;

	var scene = mainRenderer.s;
    //var camera = new THREE.OrthographicCamera( width/(-2), width/2, height/2, height/(-2), 1, 1000);
    var camera = new THREE.OrthographicCamera( width/(-64), width/64, height/64, height/(-64), 0.001, 1000);
	var renderer = new THREE.WebGLRenderer();
	renderer.setSize(width, height);
	var objParent = canvas.parentNode;
	objParent.replaceChild(renderer.domElement, canvas);
	canvas = renderer.domElement;


	var camDist = 3;
	camera.position.set(camDist,camDist,camDist);
	camera.lookAt(scene.position);
	renderer.render(scene, camera);



    main = function(){

        var cPos = mainRenderer.c.position.clone();
        mainRenderer.oc.localToWorld(cPos);
        this.c.position.set(cPos.x, cPos.y, cPos.z);

        this.c.lookAt(mainRenderer.oc.position);

		this.r.render(this.s, this.c);
    }
    return {s:scene, c:camera, r:renderer, main:main};



})("SecondCanvas");
    







