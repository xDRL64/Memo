	

mainRenderer = (function(canvasID){

    var scene, camera, renderer;
	var width, height;
	var canvas;
	var objParent;
	var mymouse;

	scene = new THREE.Scene();

	canvas = document.getElementById(canvasID);
	var debug = document.getElementById("debug");

	width = canvas.clientWidth;
	height = canvas.clientHeight;

	camera = new THREE.PerspectiveCamera(60, width/height, .1, 500);
    
	renderer = new THREE.WebGLRenderer({alpha: true});
    renderer.domElement.style.backgroundColor = "rgba(0, 0, 0, 1)";

	renderer.setSize(width, height);
	objParent = canvas.parentNode;
	objParent.replaceChild(renderer.domElement, canvas);
    canvas = renderer.domElement;
    canvas.oncontextmenu = function(e){e.preventDefault();};

	var cube = makePhongCube(.1,.1,.1, 0xffffff);
    scene.add( cube );


	var wAxis = makeWorldAxis(4,0xFF0000,0x00FF00,0x0000FF)
    scene.add( wAxis );


	var light = makePointLight(0xffffff, 1, 100);
	light.position.set( 2, 3, 4 );
    scene.add( light );

	mymouse = makeMouseDeltaSystem(canvas, mymouse);

	var camDist = 3;
	camera.position.set(camDist,camDist,camDist);
	camera.lookAt(scene.position);
    renderer.render(scene, camera);

    // objet parent de la camera qui sert de pivot
    camPivot = new THREE.Object3D();
    camPivot.add(camera);
    scene.add(camPivot);




    
	var rightcamLine = makeLine([0,0,0], [0,0,0], 0xFF00FF);
    //scene.add(rightcamLine);
    



    // RAY SETTINGS
    _rayPos = [2,3,-1];
    _rayTarget = [0.9,1.5,0.1];

    // CREER LE PLAN
    var plane = makeUnlitYplane2(5, 5, 0xffff00);
    plane.material.transparent = true;
    plane.material.opacity = .4;
    scene.add( plane );

    var planeNormal = makeLine([0,0,0], [0,1,0], 0xFF00FF);
    plane.add(planeNormal);

    // CREER LINE MESH
    var RAY = makeLine([0,0,0],[0,0,0], 0x77ff66);
    scene.add( RAY );
    var LONGRAY = makeLine([0,0,0],[0,0,0], 0x338822);
    scene.add( LONGRAY );
    var ANY = makeLine([0,0,0],[0,0,0], 0xffbb66);
    scene.add( ANY );
    var NORMAL_ANYLEN = makeLine([0,0,0],[0,0,0], 0xffff66);
    scene.add( NORMAL_ANYLEN );
    var PLANETORAY = makeLine([0,0,0],[0,0,0], 0x99aaff);
    scene.add( PLANETORAY );

    DEB = makeLine([0,0,0],[0,0,0], 0xffffff);
    scene.add( DEB );
    DEB2 = makeLine([0,0,0],[0,0,0], 0x000000);
    scene.add( DEB2 );

    var triangle = makeUnlitYtriangle(2.5, 0xff0000);
    plane.add(triangle);


    main = function(){

        // trouve l'axe horizontal par rapport a la camera
        var camRight = new THREE.Vector3(0,1,0);
        camRight.crossVectors(camRight,camera.getWorldDirection());
        this.cright = [camRight.x, camRight.y, camRight.z];

        /*
        // update display rightcamLine
        var cRightLineTarget = new THREE.Vector3(-this.cright[0]*10,this.cright[1]*10,-this.cright[2]*10);
        this.crightline.geometry.vertices[1].copy(cRightLineTarget);
        this.crightline.geometry.verticesNeedUpdate = true;
        */

        // rotation cam avec souris
        doRotationFromWorldSpaceAxis([0,1,0], this.m.dx, this.plane);
        if(!LOCK_Y)
            doRotationFromWorldSpaceAxis(this.cright, -this.m.dy, this.plane);
    



        // CALCULE
        var rayPos = VEC3(_rayPos);
        var rayTar = VEC3(_rayTarget);
        var ray = rayTar.clone().sub(rayPos);

        var longrayPos = rayTar.clone();
        var longrayTar = longrayPos.clone().add(ray.clone().multiplyScalar(2));

        var anyPos = this.plane.localToWorld( this.plane.geometry.vertices[0].clone() );
        var anyTar = rayPos;
        var any = anyTar.clone().sub(anyPos);

        var planeNormalPos = this.planeNormal.localToWorld(this.planeNormal.geometry.vertices[0].clone());
        var planeNormalTar = this.planeNormal.localToWorld(this.planeNormal.geometry.vertices[1].clone());
        var planeNormal = planeNormalTar.clone().sub(planeNormalPos);
        
        var planeNormalWithAnyLenPos = anyPos;
        var planeNormalWithAnyLenTar = anyPos.clone().add( planeNormal.clone().multiplyScalar(any.length()) );
        var planeNormalWithAnyLen = planeNormalWithAnyLenTar.clone().sub(planeNormalWithAnyLenPos);

        var planeToRay = planeNormalWithAnyLen.clone().multiplyScalar( 
            planeNormalWithAnyLen.dot(any) / planeNormalWithAnyLen.dot(planeNormalWithAnyLen)
        );
        var planeToRayPos = rayPos.clone().sub(planeToRay);
        var planeToRayTar = planeToRayPos.clone().add(planeToRay);

        var ratio = planeToRay.dot(ray) / planeToRay.dot(planeToRay);

        var rayIntersection = ray.clone().negate().divideScalar( ratio );
        var intersection = rayPos.clone().add(rayIntersection);
        


        var A = this.tris.localToWorld(this.tris.geometry.vertices[0].clone());
        var B = this.tris.localToWorld(this.tris.geometry.vertices[1].clone());
        var C = this.tris.localToWorld(this.tris.geometry.vertices[2].clone());
        
        var I = intersection;
        var projected;
        // A process
        var BtoC = C.clone().sub(B);
        var BtoA = A.clone().sub(B);
        projected = VEC3( proj(TAB(BtoA), TAB(BtoC)) );
        var Aopp = B.clone().add(projected);
        var AtoBC = Aopp.clone().sub(A);
        var AtoI = I.clone().sub(A);
        projected = VEC3( proj(TAB(AtoI), TAB(AtoBC)) );
        A_barypos = projected.length();
        A_barylen = AtoBC.length();
        A_baryfac = 1 - (A_barypos / A_barylen);

        /*
        DEB.geometry.vertices[0].copy(A);
        DEB.geometry.vertices[1].copy(Aopp);
        DEB.geometry.verticesNeedUpdate = true;
        
        DEB2.geometry.vertices[0].copy(A);
        DEB2.geometry.vertices[1].copy(A.clone().add(projected));
        DEB2.geometry.verticesNeedUpdate = true;
*/

        B_baryfac = bary(B,C,A, I);
        C_baryfac = bary(C,A,B, I);

        if(A_baryfac>=0 && B_baryfac>=0 && C_baryfac>=0)
            this.cube.material.color.setHex(0x00ff00);
        else
            this.cube.material.color.setHex(0xffffff);




        // UPDATE DISPLAY
        this.RAY.geometry.vertices[0].copy(rayPos);
        this.RAY.geometry.vertices[1].copy(rayTar);
        this.RAY.geometry.verticesNeedUpdate = true;

        this.LONGRAY.geometry.vertices[0].copy(longrayPos);
        this.LONGRAY.geometry.vertices[1].copy(longrayTar);
        this.LONGRAY.geometry.verticesNeedUpdate = true;

        this.ANY.geometry.vertices[0].copy(anyPos);
        this.ANY.geometry.vertices[1].copy(anyTar);
        this.ANY.geometry.verticesNeedUpdate = true;

        this.NORMAL_ANYLEN.geometry.vertices[0].copy(planeNormalWithAnyLenPos);
        this.NORMAL_ANYLEN.geometry.vertices[1].copy(planeNormalWithAnyLenTar);
        this.NORMAL_ANYLEN.geometry.verticesNeedUpdate = true;
        
        this.PLANETORAY.geometry.vertices[0].copy(planeToRayPos);
        this.PLANETORAY.geometry.vertices[1].copy(planeToRayTar);
        this.PLANETORAY.geometry.verticesNeedUpdate = true;

        this.cube.position.copy(intersection);
        
        



        this.r.render(this.s, this.c);
    }
    return {
        m:mymouse, s:scene, c:camera, r:renderer, main:main, oc:camPivot,
        cright:[0,0,0], crightline:rightcamLine,
        plane:plane, planeNormal:planeNormal, cube:cube, tris:triangle,
        RAY:RAY, LONGRAY:LONGRAY, ANY:ANY, NORMAL_ANYLEN:NORMAL_ANYLEN, PLANETORAY:PLANETORAY,
    };



})("MainCanvas");
    
