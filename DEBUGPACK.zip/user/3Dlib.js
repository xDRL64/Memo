
function makeLine(start, end, color){
	var material = new THREE.LineBasicMaterial({ color: color });

	var geometry = new THREE.Geometry();
	geometry.vertices.push(
		new THREE.Vector3( start[0], start[1], start[2] ),
		new THREE.Vector3(   end[0],   end[1],   end[2] ),
	);

	var line = new THREE.Line( geometry, material );
	
	return line
}

function makeWorldAxis(length, rCol, uCol, fCol){
	var wAxis = new THREE.Object3D();
	wAxis.add( makeLine([0,0,0], [length,0,0], rCol) );
	wAxis.add( makeLine([0,0,0], [0,length,0], uCol) );
	wAxis.add( makeLine([0,0,0], [0,0,length], fCol) );
	return wAxis;
}

function makeUnlitYplane(width, height, color){
	var geometry = new THREE.PlaneGeometry( width, height);
	var material = new THREE.MeshBasicMaterial(
		{color: color, side: THREE.DoubleSide}
	);
	var plane = new THREE.Mesh( geometry, material );
	plane.rotation.x = Math.PI/2;
	
	return plane;
}

function makeUnlitYplane2(width, height, color){
    var geometry = new THREE.PlaneGeometry( width, height);
    geometry.rotateX(Math.PI/2);

	var material = new THREE.MeshBasicMaterial(
		{color: color, side: THREE.DoubleSide}
    );
    
	var plane = new THREE.Mesh( geometry, material );
	return plane;
}


function makeUnlitYtriangle(size, color){
    var geometry = new THREE.Geometry();
    geometry.vertices.push(
        new THREE.Vector3( (size/4)-(size/2), 0, (size/4)-(size/2) ),
        new THREE.Vector3( (size/4)+(size/2), 0, (size/4)-(size/2) ),
        new THREE.Vector3(  (size/4)-(size/2), 0,(size/4)+(size/2) )
    );
    geometry.faces.push( new THREE.Face3( 0, 1, 2 ) );
	var material = new THREE.MeshBasicMaterial(
        {color: color, side: THREE.DoubleSide}
    );

	return new THREE.Mesh(geometry, material);
}


function makePhongCube(x,y,z, col){
    var geometry = new THREE.BoxGeometry( x, y, z );
	var material = new THREE.MeshPhongMaterial( { color: col, emissive: 0x222222 } );
	var cube = new THREE.Mesh( geometry, material );
	
	return cube;
}

function makePointLight(col, intensity, distance){
	var light = new THREE.PointLight( col, intensity, distance );
	
	return light;
}

function doRotationFromWorldSpaceAxis(axis, angle, object){
	var PI180 = (Math.PI/180);
	var v = new THREE.Vector3(axis[0], axis[1], axis[2]);
	v.normalize();

	var q = new THREE.Quaternion();
	q.setFromAxisAngle( v, angle * PI180 );;
	object.quaternion.multiplyQuaternions( q, object.quaternion );
}

function TAB(threeVec3){
    return [threeVec3.x, threeVec3.y, threeVec3.z];
}

function VEC3(tab){
    return new THREE.Vector3(tab[0], tab[1], tab[2]);
}

function dot(A,B){
	return A[0]*B[0] + A[1]*B[1] + A[2]*B[2];
}

// proj 'de' 'sur'
function proj(de, sur){
    var ration = dot(de,sur) / dot(sur,sur);
    return [ration*sur[0], ration*sur[1], ration*sur[2]];
}

// weight de A dans Abc par rapport a pos
function bary(A, b,c, pos){
    var B = b;
    var C = c;
    var I = pos;
    var projected;
    // process
    var BtoC = C.clone().sub(B);
    var BtoA = A.clone().sub(B);
    projected = VEC3( proj(TAB(BtoA), TAB(BtoC)) );
    var Aopp = B.clone().add(projected);
    var AtoBC = Aopp.clone().sub(A);
    var AtoI = I.clone().sub(A);
    projected = VEC3( proj(TAB(AtoI), TAB(AtoBC)) );
    var A_barypos = projected.length();
    var A_barylen = AtoBC.length();
    var A_baryfac = 1 - (A_barypos / A_barylen);
    return A_baryfac;
}